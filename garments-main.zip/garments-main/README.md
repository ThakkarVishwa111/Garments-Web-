# garments
this is only frontend based project using HTML CSS and JAVASCRIPT
